# Project Breadcrumbs — Preliminary Data Model

**Status:** Conceptual schema; implementation not selected

## 1. Design principles

- Use pseudonymous participant and site codes in operational datasets.
- Keep direct participant contact details separate from event data.
- Minimize exact location collection and access.
- Use unique IDs and timestamps consistently.
- Distinguish sensor observations from human-verified outcomes.
- Track missing, delayed, and failed records explicitly.
- Do not encode a person's identity or inferred guilt in event records.

## 2. Core entities

### Module
| Field | Meaning |
|---|---|
| module_id | Stable unique device identifier |
| hardware_revision | Physical design revision |
| firmware_revision | Firmware build |
| status | Available, deployed, maintenance, lost, retired |
| created_at | Module registration time |

### Participant
| Field | Meaning |
|---|---|
| participant_code | Pseudonymous participant identifier |
| consent_version | Agreement version |
| consent_timestamp | Recorded authorization time |
| status | Active, withdrawn, suspended |

Contact information should be stored separately with restricted access.

### Deployment
| Field | Meaning |
|---|---|
| deployment_id | Unique deployment identifier |
| module_id | Assigned module |
| participant_code | Pseudonymous participant |
| site_code | Pseudonymous deployment site |
| start_timestamp | Deployment start |
| end_timestamp | Deployment end |
| status | Prepared, deployed, retrieved, recovered, lost, failed |
| location_record_ref | Restricted location reference, if approved |

### Event
| Field | Meaning |
|---|---|
| event_id | Unique event identifier |
| deployment_id | Related deployment |
| module_id | Reporting module |
| event_type | Light trigger, movement, power, communications, recovery |
| sensor_timestamp | Device-reported timestamp |
| received_timestamp | Server receipt time |
| trigger_metadata | Threshold and diagnostic information |
| validation_status | Unreviewed, reviewed, false trigger, indeterminate |

### Image
| Field | Meaning |
|---|---|
| image_id | Unique image identifier |
| event_id | Related event |
| frame_index | 1, 2, or 3 |
| capture_timestamp | Actual capture time |
| secure_object_ref | Restricted storage reference |
| integrity_hash | Integrity verification value |
| access_class | Restricted classification |
| retention_until | Approved deletion date |

### Recovery
| Field | Meaning |
|---|---|
| recovery_id | Unique recovery record |
| deployment_id | Related deployment |
| recovery_timestamp | Recovery time |
| recovery_status | Recovered, unrecovered, later returned |
| device_condition | Functional, damaged, failed |
| recovery_method | Controlled category; avoid unnecessary personal data |

## 3. Event taxonomy

Recommended initial event types:
- `LIGHT_TRIGGER`
- `MOTION_TRIGGER` (if motion sensor is implemented)
- `IMAGE_CAPTURE_COMPLETE`
- `IMAGE_CAPTURE_PARTIAL`
- `LOW_BATTERY`
- `POWER_RESET`
- `SYNC_SUCCESS`
- `SYNC_FAILURE`
- `MODULE_RECOVERED`
- `DEPLOYMENT_CLOSED`

A `LIGHT_TRIGGER` is a sensor observation, not proof of opening or theft.

## 4. Timestamp policy

Store timestamps in UTC in machine-readable records and retain the device's clock-synchronization status. For analysis, convert to local time using the deployment site's time zone. Record clock drift and missing timestamps.

## 5. Data quality flags

Use explicit flags for:
- incomplete image burst;
- uncertain clock;
- sensor false trigger;
- duplicate upload;
- missing location;
- offline-buffered record;
- unknown recovery time;
- device malfunction.

## 6. Public reporting

Public outputs should use aggregated or sufficiently de-identified statistics. Do not publish participant names, home addresses, precise private-location traces, identifiable images, or data that could expose a participant or bystander.
