# Project Breadcrumbs — 90-Day Pilot Protocol (Draft)

**Protocol version:** 0.1  
**Status:** Planning draft; not approved for field deployment  
**Sponsor/organization:** Nuera Research and Developmental Laboratories

## 1. Purpose

Assess the feasibility of using reusable, event-monitoring packages to collect structured observations about package deployment, disturbance, opening-related sensor events, module movement, recovery, and reuse.

This is a feasibility and methods pilot. It is not designed or powered to estimate community-wide theft prevalence, identify offenders, establish guilt, or demonstrate that a particular intervention reduces crime.

## 2. Primary hypothesis

A low-cost, reusable monitoring module can, after engineering validation, produce sufficiently reliable deployment and event records to support useful descriptive analysis of package-related events and recovery outcomes in a small voluntary pilot.

## 3. Pilot targets

The initial concept proposes:
- Duration: 90 days.
- Hardware: 5–10 reusable modules.
- Activity: approximately 120 deployment cycles.
- Preliminary budget: $600–$900.

These are planning targets, not confirmed capacity or a validated budget. A deployment cycle must be defined consistently before the pilot begins.

## 4. Study setting and participants

Proposed participants are homeowners who voluntarily agree to participate and place research packages on their own porches or other locations they control. Written authorization and clear participant instructions are required.

Before recruitment or deployment, the project must complete legal, privacy, safety, insurance, and ethics review appropriate to the actual locations and methods.

## 5. Study design

A small, repeated-deployment observational feasibility study.

Each cycle should record:
1. Module inspection and readiness.
2. Participant-authorized placement.
3. Deployment timestamp and deployment record.
4. Monitoring period.
5. Any device-generated event records.
6. Retrieval/recovery outcome.
7. Device inspection and data synchronization.
8. Reset and redeployment, if appropriate.

The protocol must define maximum deployment duration, check-in schedule, recovery window, and lost-device procedure before field use.

## 6. Data collected

Minimum proposed data:
- module identifier;
- deployment identifier;
- deployment start/end timestamps;
- participant/site code rather than public homeowner identity;
- device health and battery status;
- event type and timestamp;
- sensor-trigger confidence/diagnostic fields;
- image references and capture timestamps, if camera use is approved;
- recovery status and recovery timestamp;
- maintenance and failure records.

Location data should be minimized and collected only if the location method, purpose, legal basis, access, and retention have been approved. Exact home addresses and precise location histories must not appear in public reports or this repository.

## 7. Outcomes and metrics

### Primary feasibility outcomes
- Successful deployment cycles / attempted cycles.
- Device uptime during scheduled monitoring.
- Event-record completeness.
- Three-frame capture completion rate following qualifying triggers.
- False-trigger rate during controlled testing and field operation.
- Module recovery rate within the defined recovery window.
- Data synchronization success rate.

### Secondary descriptive outcomes
- Time from deployment to first event.
- Time from event to recovery.
- Number of redeployment cycles per module.
- Maintenance interventions per cycle.
- Cost per completed deployment cycle.
- Participant feedback and burden.

### Interpretation
A sensor trigger is not proof that a theft occurred. An image is not proof of identity or intent. A recovered device's location does not by itself establish a disposal pattern. Results must include denominators, missing-data rates, and limitations.

## 8. Safety and incident response

- Volunteers must not confront, follow, detain, or attempt to identify anyone.
- Participants must be instructed to contact appropriate authorities if they believe an incident requires immediate assistance.
- Do not deploy in a way that creates a trip hazard, obstructs access, or encourages dangerous interaction.
- Establish a lost-device and data-breach response procedure.
- Suspend a deployment if the device behaves unexpectedly, creates a safety issue, or raises a privacy concern.

## 9. Analysis plan

Use descriptive statistics:
- counts and proportions by outcome;
- event rates per deployment cycle;
- median and range for elapsed times where data permit;
- module-level reliability and recovery summaries;
- missingness and false-trigger analysis;
- qualitative summary of participant feedback.

Avoid causal claims or generalization beyond the small sample. Do not publish identifiable images, participant identities, precise home locations, or individual movement trails.

## 10. Pilot phases

### Phase 0 — Readiness (before day 1)
- Finalize hardware and software.
- Complete bench tests.
- Complete legal/privacy/safety review.
- Finalize consent and participant materials.
- Finalize data retention and access controls.
- Confirm budget and insurance.

### Phase 1 — Prototype verification
- Test trigger, camera, storage, power, and recovery workflow.
- Resolve critical defects before field use.

### Phase 2 — Participant onboarding
- Obtain written participation and property authorization.
- Explain the device, data collected, risks, withdrawal, and incident procedure.
- Assign participant and deployment codes.

### Phase 3 — Field deployments (up to 90 days)
- Conduct scheduled, documented deployments.
- Monitor device health and participant concerns.
- Follow the approved recovery and data procedures.

### Phase 4 — Analysis and reporting
- Reconcile deployment and recovery records.
- Analyze reliability, recovery, data quality, and costs.
- Report limitations and recommendations.
- Delete or retain data according to the approved schedule.

## 11. Go/no-go criteria

Before field launch, establish numeric acceptance thresholds for:
- trigger false-positive rate;
- three-frame capture success;
- image quality;
- battery runtime;
- data integrity;
- recovery workflow;
- privacy/security review completion.

Do not begin field deployment while critical safety, privacy, legal, or data-security issues remain unresolved.
