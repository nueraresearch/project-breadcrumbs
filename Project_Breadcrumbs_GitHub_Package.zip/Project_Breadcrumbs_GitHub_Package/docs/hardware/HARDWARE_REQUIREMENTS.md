# Reusable Monitoring Module — Hardware Requirements & Conceptual Architecture

**Revision:** 1.0  
**Status:** Preliminary requirements; not a finalized engineering design

## 1. Design objective

Develop a compact, reusable monitoring module that can be installed in an authorized research package and record defined package events for a voluntary community study.

The module should prioritize reliable event capture, recoverability, low operating cost, maintainability, and controlled data collection.

## 2. Confirmed project-level direction

The following reflect decisions expressed in the project discussion:
- The module is intended to be reusable and recoverable.
- The program is voluntary.
- Participating homeowners place research packages on their own porches with their authorization.
- The intended study concerns theft-related package events and recovery patterns.
- The camera is intended to face outward toward the package-opening area.
- The camera should capture a burst of three still images following an opening trigger.
- A light-sensitive sensor is preferred as the opening trigger.
- No audio or continuous video has been specified.

These decisions do not establish technical feasibility or legal permissibility.

## 3. Functional architecture

### A. Event sensing
Proposed functions:
- Detect a light-level change consistent with package opening.
- Optionally detect movement or removal using an inertial sensor.
- Record event timestamps and event type.
- Apply filtering and lockout logic to reduce duplicate or false events.

**Important limitation:** A light sensor detects illumination, not the act of opening itself. Sunlight changes, shadows, porch lighting, package movement, and light leaks may trigger it. The trigger must be tested and must not be represented as definitive proof of opening.

### B. Imaging
Proposed functions:
- Outward-facing camera.
- Three still images per qualifying event.
- No audio recording.
- No continuous video.
- Images associated with a module ID, deployment ID, event ID, and timestamps.
- Local storage with controlled access.

The exact camera sensor, lens, image resolution, flash/illumination approach, and image-retention policy remain open.

### C. Location
Desired research capability:
- Record an authorized deployment location.
- Where technically and legally approved, record subsequent module-location observations relevant to movement and recovery.

The project has not selected GPS/GNSS, cellular, Wi-Fi, Bluetooth, or another location method. Continuous location tracking is not a confirmed requirement. A location strategy must be justified against cost, battery life, privacy, coverage, and research value.

### D. Communications
Proposed capability:
- Store records locally when offline.
- Transfer approved records securely when connectivity is available.
- Avoid unnecessary transmission of image data.
- Provide a way to verify successful upload and prevent duplicate records.

Communications technology and service costs are undecided.

### E. Power management
Proposed capability:
- Low-power standby.
- Wake relevant subsystems on a qualifying event.
- Monitor battery condition.
- Support safe charging or battery replacement, depending on final design.

Battery chemistry, capacity, charging method, and runtime target are not yet selected.

### F. Physical enclosure
Proposed characteristics:
- Compact and robust for ordinary porch/package conditions.
- Protect electronics from handling and reasonable weather exposure.
- Provide a defined outward camera aperture and a separate light-sensor optical path if required.
- Permit inspection, charging, reset, and repair.
- Include a unique module identifier and project contact/return information as appropriate.

Enclosure dimensions, ingress protection, mounting method, and materials remain open.

## 4. Preliminary requirements table

| ID | Requirement | Status / verification |
|---|---|---|
| HW-01 | Module shall be reusable across deployment cycles | Proposed; cycle testing |
| HW-02 | Module shall have a unique device identifier | Proposed; data/firmware test |
| HW-03 | Opening trigger shall use a light-sensitive sensor | User-selected direction; bench test |
| HW-04 | Trigger shall initiate a three-still-image sequence | User-selected behavior; timing test |
| HW-05 | Camera shall face outward toward the package-opening area | User-selected direction; layout review |
| HW-06 | Device shall not record audio | Design constraint; hardware/firmware review |
| HW-07 | Device shall not continuously record video | Design constraint; firmware review |
| HW-08 | Device shall retain event records if offline | Proposed; offline test |
| HW-09 | Device shall support authorized location observations | Desired capability; architecture TBD |
| HW-10 | Device shall support secure data handling | Required design objective; security review |
| HW-11 | Device shall indicate relevant operating state | Proposed; usability test |
| HW-12 | Device shall support safe recovery and redeployment | Proposed; operational test |

## 5. Trigger logic concept

A possible event-detection sequence:
1. Sample ambient light during standby.
2. Establish a baseline or adaptive baseline.
3. Detect a configured increase in illumination.
4. Apply threshold, duration, and lockout checks.
5. If the event qualifies, create an event record and activate the camera.
6. Capture three still images at configured intervals.
7. Store image references and capture timestamps.
8. Return to a defined monitoring state after the event sequence.

Thresholds, sampling interval, debounce duration, and lockout period must be determined experimentally.

## 6. Reliability and misuse controls

- No remote command to activate imaging without an approved and documented event policy.
- No audio capability in the pilot hardware.
- No facial recognition or biometric processing.
- Access to image records must be restricted and logged.
- Device status and event records should distinguish sensor triggers from verified package openings.
- The system must not provide instructions or features for pursuing, confronting, or identifying a person.

## 7. Engineering unknowns

- Exact microcontroller and camera platform.
- Sensor type and optical placement.
- Camera wake and capture latency.
- Image quality under day, dusk, and porch-light conditions.
- Whether three frames can be captured within the desired interval.
- Storage capacity and encryption implementation.
- Location method and update policy.
- Communications coverage and recurring costs.
- Battery life under realistic event and standby profiles.
- Weather resistance and enclosure design.
- Final unit cost and assembly effort.
