# Camera Subsystem — Outward-Facing, Light-Triggered Three-Image Capture

**Revision:** 1.0  
**Status:** Proposed subsystem definition; not built or validated

## 1. Purpose

The camera subsystem is intended to document a package-opening event during an authorized, voluntary research deployment. It is designed for event-triggered still photography, not continuous surveillance.

## 2. Direction and placement

- Camera faces outward toward the package-opening area.
- Camera is integrated into the package/module assembly.
- The light sensor may use a separate optical aperture and does not need to share the camera's viewing direction.
- The field of view and physical placement must be evaluated to limit unnecessary capture of neighboring properties, public walkways, and unrelated activity.
- Final placement must be reviewed for safety, privacy, and applicable law.

The project has selected outward-facing orientation as its design direction. Exact mounting geometry and field of view remain undecided.

## 3. Trigger

**Preferred trigger:** light-sensitive sensor.

Concept:
- The module monitors ambient light in a low-power state.
- A qualifying increase in illumination initiates the event sequence.
- Trigger logic uses thresholding, duration checks, and lockout to reduce false activations.

A light sensor does not inherently know that a package has opened. It may respond to sunlight, shadows, porch lights, package movement, or other illumination changes. The system must label the record as a sensor-triggered event, not as verified theft or verified opening.

## 4. Three-image sequence

The required behavior is three still photographs for each qualifying trigger.

A provisional timing example for bench testing is:
- Frame 1: as soon as practical after trigger validation;
- Frame 2: approximately 1 second later;
- Frame 3: approximately 2.5 seconds after the first trigger.

These timings are examples only. Camera wake latency and actual capture intervals must be measured. The first frame may be delayed by sensor wake-up and exposure.

No continuous video and no audio recording are included in the proposed pilot.

## 5. Image handling

Each image should be associated with:
- module ID;
- deployment ID;
- event ID;
- frame index (1–3);
- sensor-trigger timestamp;
- actual image-capture timestamp;
- image integrity/checksum reference;
- upload status, if applicable.

Images should be encrypted at rest and in transit where transmitted. Access must be limited to named, authorized project personnel and logged. Public reports should use aggregate statistics and should not publish identifiable images.

## 6. Privacy-by-design controls

Before field use:
- Complete jurisdiction-specific legal review.
- Establish participant authorization and written deployment terms.
- Determine whether notice or other disclosure is required or appropriate for each deployment.
- Define camera field-of-view limits and placement rules.
- Define access, retention, deletion, incident response, and participant withdrawal procedures.
- Prohibit facial recognition, biometric identification, audio capture, and continuous video.
- Establish a process for handling incidental capture of neighbors, visitors, delivery workers, or other bystanders.

Property-owner authorization is necessary for the proposed deployment model but does not, by itself, resolve every privacy or recording-law issue involving people who may be photographed.

## 7. Verification tests

- Light-trigger sensitivity under controlled illumination changes.
- False-trigger rate under changing daylight, shadows, porch lighting, and light leaks.
- Time from trigger qualification to first captured image.
- Actual spacing between the three images.
- Image clarity at intended distances and lighting conditions.
- Storage integrity after power interruption.
- Duplicate-trigger handling and lockout behavior.
- Battery consumption in standby and during capture.
- Verification that no audio or continuous video is recorded.
- Review of camera field of view for incidental capture.

## 8. Open decisions

- Sensor technology: analog photodiode/LDR versus digital ambient-light sensor.
- Camera module and lens.
- Resolution and image format.
- Low-light performance and whether supplemental illumination is appropriate.
- Trigger threshold and debounce settings.
- Frame timing.
- Local storage capacity and encryption design.
- Whether any image transfer is needed during the pilot.
- Exact disclosure/notice approach following legal review.
