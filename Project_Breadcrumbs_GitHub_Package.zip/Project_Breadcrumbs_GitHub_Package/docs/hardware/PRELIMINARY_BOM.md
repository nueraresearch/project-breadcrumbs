# Preliminary Bill of Materials — Functional Categories

**Revision:** 1.0  
**Status:** Category-level BOM; no final parts selected and no prices validated

This BOM identifies functional elements needed to develop a prototype. It is not a purchase-ready parts list. Exact components must be selected after requirements, interfaces, power budget, and prototype constraints are established.

| Subsystem | Item / category | Purpose | Selection status |
|---|---|---|---|
| Control | Low-power microcontroller or embedded controller | Sensor monitoring, event logic, image coordination | TBD |
| Camera | Embedded still-image camera module | Three-frame capture | TBD |
| Optics | Lens / camera aperture | Outward-facing field of view | TBD |
| Trigger | Light-sensitive sensor | Detect illumination change associated with opening | TBD |
| Trigger optics | Sensor aperture / light path | Expose sensor to relevant light change | TBD |
| Motion | Accelerometer / inertial sensor | Optional movement/removal observations | TBD |
| Location | GNSS or other approved location subsystem | Authorized location observations | Architecture TBD |
| Communications | Cellular, Wi-Fi, Bluetooth, or gateway interface | Data transfer | Architecture TBD |
| Storage | Nonvolatile memory | Event records and image storage | TBD |
| Security | Secure element or equivalent key storage, if required | Device identity and cryptographic key protection | TBD |
| Power | Rechargeable battery or replaceable battery system | Module power | TBD |
| Power | Charging / protection / regulation circuitry | Safe power management | TBD |
| Feedback | Status LED(s) | Device state indication | TBD |
| Enclosure | Reusable enclosure and mounting hardware | Protect and position components | TBD |
| Assembly | PCB, connectors, wiring, fasteners | Integration | TBD |
| Recovery | Return label / reward insert | Encourage hardware return | Program design TBD |

## Cost status

The project proposal currently gives a preliminary pilot budget target of **$600–$900** for 5–10 modules and approximately 120 deployment cycles. This figure has not been validated and may not cover engineering labor, shipping, connectivity, insurance, participant incentives, replacement parts, or data hosting.

No per-module price is approved. Build a supplier-backed costed BOM after selecting components and obtaining current quotes.

## Required next steps

1. Choose controller and camera platform based on capture latency and low-power standby.
2. Select light sensor and test its optical response in a representative package.
3. Determine whether location and cellular reporting are essential to the first pilot.
4. Calculate battery capacity using measured standby and event loads.
5. Select storage capacity based on image count, image size, and retention policy.
6. Prototype enclosure and evaluate camera field of view.
7. Obtain current supplier quotes and add assembly, shipping, and contingency.
