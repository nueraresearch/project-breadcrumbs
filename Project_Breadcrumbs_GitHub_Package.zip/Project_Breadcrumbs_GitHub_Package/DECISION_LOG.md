# Project Breadcrumbs — Decision Log

This log separates user-confirmed project direction from preliminary proposals and unresolved items.

## A. Confirmed project direction from the project owner

| ID | Decision / direction | Notes |
|---|---|---|
| D-01 | Project name: Project Breadcrumbs | Community safety research pilot |
| D-02 | Organization: Nuera Research and Developmental Laboratories | As supplied by project owner |
| D-03 | Tagline: “Following patterns others miss.” | As supplied by project owner |
| D-04 | Central philosophy: “The goal isn't to catch people. The goal is to understand the system.” | Preserve as project framing |
| D-05 | Program is voluntary | Homeowners participate by choice |
| D-06 | Participants place packages on their own porches/property with authorization | Proposed bait-package research deployment |
| D-07 | Camera faces outward toward the person opening the package | User-selected design direction |
| D-08 | Camera captures a three-shot burst when package opening is detected | User-selected behavior |
| D-09 | A light-sensitive camera switch/sensor is preferred as the opening trigger | User-selected trigger direction |
| D-10 | Module is intended to be low-cost, reusable, and recoverable | Project design goals |

## B. Project proposal targets supplied by the owner

| Item | Target | Status |
|---|---:|---|
| Pilot duration | 90 days | Proposed |
| Number of modules | 5–10 | Proposed |
| Deployment cycles | Approximately 120 | Proposed |
| Pilot budget | $600–$900 | Preliminary, unvalidated |

## C. Preliminary engineering proposals (not yet approved)

- Digital ambient-light sensor rather than a simple LDR, subject to testing.
- Threshold, duration, and lockout logic to reduce false triggers.
- Example frame timing of 0, 1, and 2.5 seconds; not final.
- Local encrypted image storage.
- Secure transfer when connectivity is available.
- Optional movement sensor.
- Location capability, with method and frequency undecided.
- Rechargeable power system.
- Status indicator and serviceable enclosure.
- Aggregate reporting and restricted image access.

## D. Open decisions

1. Exact camera module, lens, resolution, and low-light performance.
2. Light sensor type, optical placement, threshold, and false-trigger acceptance criteria.
3. Exact three-frame timing and camera wake latency.
4. Whether movement sensing is included in the first prototype.
5. Whether location is included in the first pilot; if so, method and update policy.
6. Communications method and recurring cost.
7. Battery type, capacity, charging method, and runtime target.
8. Storage capacity, encryption implementation, and image retention schedule.
9. Enclosure dimensions, materials, weather resistance, and mounting.
10. Recovery reward amount, terms, and redemption process.
11. Exterior notice/disclosure policy after legal review.
12. Participant consent materials and withdrawal process.
13. Numeric go/no-go thresholds for the pilot.
14. Costed BOM based on selected components and supplier quotes.

## E. Change control

When a decision is finalized:
- assign or update a decision ID;
- record the date and rationale;
- update affected requirements and documents;
- identify whether prototype or pilot documents need revision;
- retain prior revision history in Git.
