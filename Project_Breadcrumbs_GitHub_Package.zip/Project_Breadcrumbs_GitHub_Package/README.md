# Project Breadcrumbs

**A Community Safety Research Pilot by Nuera Research and Developmental Laboratories**  
*Following patterns others miss.*

> **The goal isn't to catch people. The goal is to understand the system.**

Project Breadcrumbs is a proposed, voluntary community research initiative exploring whether low-cost, reusable monitoring packages can help characterize theft-related events, movement, recovery, and deployment outcomes over repeated porch deployments.

This repository contains the current concept definition, preliminary hardware requirements, camera subsystem proposal, draft pilot protocol, data model, validation plan, and open decisions.

## Status

**Proposal / pre-prototype. No pilot has launched.** No funding has been requested and no participants are currently being recruited. Hardware performance, costs, legal requirements, and research value have not yet been validated.

## Repository guide

- [`docs/PROJECT_OVERVIEW.md`](docs/PROJECT_OVERVIEW.md) — purpose, problem, scope, and research questions
- [`docs/hardware/HARDWARE_REQUIREMENTS.md`](docs/hardware/HARDWARE_REQUIREMENTS.md) — preliminary module requirements and architecture
- [`docs/hardware/CAMERA_SUBSYSTEM.md`](docs/hardware/CAMERA_SUBSYSTEM.md) — outward-facing camera and light-triggered three-frame capture
- [`docs/hardware/PRELIMINARY_BOM.md`](docs/hardware/PRELIMINARY_BOM.md) — component categories, cost status, and unknowns
- [`docs/pilot/PILOT_PROTOCOL_DRAFT.md`](docs/pilot/PILOT_PROTOCOL_DRAFT.md) — proposed 90-day pilot framework
- [`docs/pilot/DEPLOYMENT_AND_OPERATIONS.md`](docs/pilot/DEPLOYMENT_AND_OPERATIONS.md) — voluntary homeowner deployment and operating cycle
- [`docs/pilot/TEST_AND_VALIDATION_PLAN.md`](docs/pilot/TEST_AND_VALIDATION_PLAN.md) — bench and field validation plan
- [`docs/data/DATA_MODEL.md`](docs/data/DATA_MODEL.md) — event and deployment data definitions
- [`docs/governance/PRIVACY_SAFETY_AND_REVIEW.md`](docs/governance/PRIVACY_SAFETY_AND_REVIEW.md) — privacy, safety, legal review, and data governance
- [`DECISION_LOG.md`](DECISION_LOG.md) — confirmed decisions, proposals, and unresolved questions

## Important interpretation

The project is a research proposal, not a validated theft-prevention product, law-enforcement tool, or guarantee of recovery. A camera event does not establish identity, intent, or criminal conduct. Data should be interpreted cautiously and reported in aggregate.

All deployments must be voluntary and authorized by the participating property owner. Before any field use, the project must complete appropriate legal, privacy, safety, and insurance review for the actual deployment locations and operating procedures.

## Initial pilot concept

The proposal currently describes:
- 90-day duration
- 5–10 reusable modules
- Approximately 120 deployment cycles
- Preliminary budget target of $600–$900

These are planning targets from the concept proposal, not validated estimates. Feasibility must be checked against the final hardware, communications plan, incentives, insurance, and operating costs.

## Contribution and revision policy

Treat requirements marked **Proposed** or **To validate** as provisional. Update the decision log when a design decision is approved. Do not describe a feature as implemented or tested until evidence is recorded in the repository.
